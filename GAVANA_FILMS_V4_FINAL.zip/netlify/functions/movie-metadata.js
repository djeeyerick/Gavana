// GAVANA FILMS metadata lookup via TMDB. Keep the API key in Netlify environment variables.
exports.handler = async (event) => {
  const key = process.env.TMDB_API_KEY;
  const title = String(event.queryStringParameters?.title || '').trim();
  const kind = String(event.queryStringParameters?.type || 'movie').toLowerCase();
  const year = String(event.queryStringParameters?.year || '').trim();
  if (!key) return { statusCode: 503, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'TMDB_API_KEY is not configured' }) };
  if (!title) return { statusCode: 400, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'title is required' }) };
  const media = kind === 'series' ? 'tv' : 'movie';
  const params = new URLSearchParams({ query: title, language: 'en-US' });
  if (year && /^\d{4}$/.test(year)) params.set(media === 'movie' ? 'year' : 'first_air_date_year', year);
  const headers = { Authorization: `Bearer ${key}`, Accept: 'application/json' };
  try {
    const searchRes = await fetch(`https://api.themoviedb.org/3/search/${media}?${params}`, { headers });
    if (!searchRes.ok) throw new Error(`TMDB search returned ${searchRes.status}`);
    const search = await searchRes.json();
    const match = (search.results || []).find(x => String(x.title || x.name || '').toLowerCase() === title.toLowerCase()) || search.results?.[0];
    if (!match) return { statusCode: 404, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: 'No matching title found' }) };
    const detailRes = await fetch(`https://api.themoviedb.org/3/${media}/${match.id}?append_to_response=credits&language=en-US`, { headers });
    if (!detailRes.ok) throw new Error(`TMDB details returned ${detailRes.status}`);
    const detail = await detailRes.json();
    const cast = (detail.credits?.cast || []).slice(0, 8).map(x => x.name).filter(Boolean);
    const director = media === 'movie'
      ? (detail.credits?.crew || []).find(x => x.job === 'Director')?.name || ''
      : (detail.created_by || []).map(x => x.name).filter(Boolean).join(', ');
    const payload = {
      title: detail.title || detail.name || match.title || match.name || title,
      overview: detail.overview || '',
      genres: (detail.genres || []).map(g => g.name).filter(Boolean),
      release_date: detail.release_date || detail.first_air_date || '',
      poster_path: detail.poster_path ? `https://image.tmdb.org/t/p/w500${detail.poster_path}` : '',
      backdrop_path: detail.backdrop_path ? `https://image.tmdb.org/t/p/w1280${detail.backdrop_path}` : '',
      cast,
      director,
      rating: detail.vote_average ? `${Number(detail.vote_average).toFixed(1)}/10` : '',
      runtime: media === 'movie' ? (detail.runtime ? `${detail.runtime} min` : '') : ((detail.episode_run_time || []).length ? `${detail.episode_run_time[0]} min/episode` : ''),
      original_language: detail.original_language || '',
      metadata_source: 'TMDB'
    };
    return { statusCode: 200, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'public, max-age=3600' }, body: JSON.stringify(payload) };
  } catch (error) {
    return { statusCode: 502, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ error: error.message || 'Metadata lookup failed' }) };
  }
};
