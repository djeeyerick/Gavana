exports.handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers, body: "" };
  if (event.httpMethod !== "POST") return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.RESEND_FROM_EMAIL;
  if (!apiKey || !from) return { statusCode: 503, headers, body: JSON.stringify({ error: "Email notification is not configured" }) };
  let payload;
  try { payload = JSON.parse(event.body || "{}"); } catch { return { statusCode: 400, headers, body: JSON.stringify({ error: "Invalid JSON" }) }; }
  const name = String(payload.name || "").trim().slice(0, 80);
  const email = String(payload.email || "").trim().slice(0, 254);
  const comment = String(payload.comment || "").trim().slice(0, 2000);
  const title = String(payload.title || "GAVANA FILMS").trim().slice(0, 200);
  const movieId = String(payload.movie_id || "").slice(0, 100);
  if (!name || !email || !comment || !movieId || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return { statusCode: 400, headers, body: JSON.stringify({ error: "Missing or invalid comment details" }) };
  }
  const esc = (v) => v.replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from,
        to: ["djeeyerick@gmail.com"],
        subject: `New GAVANA FILMS comment: ${title}`,
        html: `<h2>New comment on GAVANA FILMS</h2><p><b>Title:</b> ${esc(title)}</p><p><b>Name:</b> ${esc(name)}</p><p><b>Email:</b> ${esc(email)}</p><p><b>Movie ID:</b> ${esc(movieId)}</p><hr><p>${esc(comment).replace(/\n/g, "<br>")}</p>`
      })
    });
    if (!response.ok) {
      const detail = await response.text();
      console.error("Resend notification error:", response.status, detail);
      return { statusCode: 502, headers, body: JSON.stringify({ error: "Notification delivery failed" }) };
    }
    return { statusCode: 200, headers, body: JSON.stringify({ sent: true }) };
  } catch (error) {
    console.error("Email notification error:", error);
    return { statusCode: 502, headers, body: JSON.stringify({ error: "Notification delivery failed" }) };
  }
};
